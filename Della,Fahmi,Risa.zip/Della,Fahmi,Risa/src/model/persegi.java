/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author bayu
 */
public class persegi {
    public int sisi,panjang;
    public persegi(int s){
    sisi=s;
    }
     int getSisi(){
    return sisi;
    }
       public int LuasPersegi(){
    int LuasPersegi=sisi*sisi;
    return LuasPersegi;
    }
        public int KelilingPersegi(){
    int KelilingPersegi=4*sisi;
    return KelilingPersegi;
        }
}
