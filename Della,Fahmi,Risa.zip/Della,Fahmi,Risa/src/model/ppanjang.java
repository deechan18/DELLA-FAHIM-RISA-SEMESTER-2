/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author bayu
 */
public class ppanjang {

    private int lebar, panjang;

    public ppanjang(int l, int p) {
        lebar = l;
        panjang = p;
    }

//    public lkpp(double p) {
//        panjang = (int) p;
//    }

    public int LuasPersegiPanjang() {
        int LuasPersegiPanjang = panjang * lebar;
        return LuasPersegiPanjang;
    }

    public int KelilingPersegiPanjang() {
        int KelilingPersegiPanjang = 2 * (panjang * lebar);
        return KelilingPersegiPanjang;
    }
}
